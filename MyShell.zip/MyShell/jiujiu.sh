#!/bin/bash
clear
for ((i=1;i<=9;i++))
do
	for ((j=1;j<=9;j++))
	do
		if [ $j -le $i ] ;then
			echo -ne "$j*$i=$[$j*$i]\t"
		fi
	done
	echo
done
