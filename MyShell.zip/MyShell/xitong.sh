#!/bin/bash
uptime | awk '{print "最近15分钟CPU负载:",$NF}' | column -t
ifconfig ens32 | awk '/RX p/{print "网卡ens3下行流量:"$6$7}'
ifconfig ens32 | awk '/TX p/{print "网卡ens3上行流量:"$6$7}'
free -h | awk '/Mem/{print "内存剩余空间:"$4}'
df -h | awk '/\/$/{print "硬盘根分区剩余容量"$4}'
awk '{i++}END{print "计算机账户数量为:"i}' /etc/passwd
echo "当前登录的账户数量:`who | wc -l`"
echo "当前开启的进程数量为:`ps aux | wc -l`"
echo "本机已安装的软件包数量为:`rpm -qa | wc -l`"
