#!/bin/bash
ip1=`awk '/Invalid user/{print $10}' /var/log/secure | awk '{ip[$1]++}END{for(i in ip){print ip[i],i}}' | awk '$1>3{print $2}'`
ip2=`awk '/Failed password/{print $11}' /var/log/secure | awk '{ip[$1]++}END{for(i in ip){print ip[i],i}}' | awk '$1>3{print $2}'`
for i in `echo $ip1 $ip2`
do
	j=`echo $i | awk -F. '{print $1}'`
	expr $j + 0 &> /dev/null
	if [ $? -eq 0 ];then
		firewall-cmd --zone=block --add-source=$i &> /dev/null
	fi
done
echo "处理完成!!"
