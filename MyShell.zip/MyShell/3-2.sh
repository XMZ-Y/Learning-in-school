#!/bin/bash
read -p "请输入一个整数：" a
read -p "请输入另一个整数：" b
a=${a:-1} b=${b:-100}
[ $a -gt $b ] && echo "请先输入较小的整数！" && exit
for ((i=$a;i<=$b;i++))
do
	let sum+=i
done
	echo "从${a}到${b}的总和为：$sum"
