#!/bin/bash
anzhuang(){
yum -y reinstall gcc openssl-devel pcre-devel &>/dev/null
tar -xf nginx-1.12.2.tar.gz
cd nginx-1.12.2
./configure &>/dev/null
make &>/dev/null
make install &>/dev/null
}
jindu(){
	while :
	do
		echo -ne '\033[42m#\033[0m'
		sleep 0.2
	done
}
yum=`yum repolist | sed -n '/repolist/s/,//p' | awk '{print $2}'`
ls | grep -q nginx-1.12.2.tar.gz
if [ $? -ne 0 ];then
	echo "未找到安装包：nginx-1.12.2.tar.gz！！"
	exit 1
fi
if [ $yum -le 0 ];then
	echo "yum仓库不可用！！"
	exit 2
else
	jindu &
	anzhuang
	kill -9 $!
	echo "nginx安装成功！！"
fi
