#!/bin/bash
if [ $# -ne 1 ];then
	echo "缺少指令!"
	exit 1
fi
case $1 in
start)
	/usr/local/nginx/sbin/nginx &> /dev/null;;
stop)
	/usr/local/nginx/sbin/nginx -s stop &> /dev/null;;
restart)
	/usr/local/nginx/sbin/nginx -s stop &> /dev/null
	/usr/local/nginx/sbin/nginx &> /dev/null;;
status)
	netstat -nutlp |  grep -q nginx
	if [ $? -eq 0 ];then
		echo -e "nginx is \033[32mstart\033[0m"
	else
		echo "nginx is stop"
	fi;;
*)
	echo "指令错误!!"
	exit 2;;
esac
